create PROCEDURE get_transportation_list_with_count(count_goods_ IN int)
IS
BEGIN
    DELETE FROM OUTPUT; 

    INSERT INTO OUTPUT(
     id_ ,
     name_,
     count_goods,
     priority_
    )

    SELECT * FROM
    (
    (SELECT goods.id as id_, goods.name as name_, (warehouse2.good_count - warehouse1.good_count) AS count_goods, goods.priority as priority_ FROM warehouse2 
    INNER JOIN goods ON warehouse2.good_id = goods.id INNER JOIN warehouse1 ON warehouse2.good_id = warehouse1.good_id) 
    MINUS 
    (SELECT goods.id as id_, goods.name as name_, (warehouse2.good_count - warehouse1.good_count) AS count_goods, goods.priority as priority_ FROM warehouse2 
    INNER JOIN goods ON warehouse2.good_id = goods.id INNER JOIN warehouse1 ON warehouse2.good_id = warehouse1.good_id 
    WHERE (warehouse2.good_count - warehouse1.good_count) = '0')
    )
    WHERE ROWNUM <= count_goods_ ORDER BY priority_;
END;
/

