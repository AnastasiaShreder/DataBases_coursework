create PROCEDURE get_date_the_best_good(good_1 IN VARCHAR, good_2 IN VARCHAR)
IS
BEGIN
    DELETE FROM OUTPUT;

    INSERT INTO OUTPUT(the_best_date, good_id_1, count_1, good_id_2, count_2)
	SELECT DISTINCT table_1.create_date, table_1.good_id, table_1.cnt_1, table_2.good_id, table_2.cnt_2 FROM
    (SELECT sales.create_date, sales.good_id, COUNT(goods.name) as cnt_1 FROM sales JOIN goods ON sales.good_id = goods.id 
    WHERE goods.name = good_1 GROUP BY sales.create_date, sales.good_id) table_1
    JOIN  
    (SELECT sales.create_date, sales.good_id, COUNT(goods.name) as cnt_2 FROM sales JOIN goods ON sales.good_id = goods.id 
    WHERE goods.name = good_2 GROUP BY sales.create_date, sales.good_id) table_2
    ON 
    table_1.create_date = table_2.create_date
    WHERE table_1.good_id IS NOT NULL AND table_2.good_id IS NOT NULL AND
    table_1.cnt_1 > table_2.cnt_2;

--    (SELECT COUNT(sales.good_id) FROM sales WHERE good_id = (SELECT id FROM goods WHERE goods.name = 'Нашивка детская')) > 
--    (SELECT COUNT(sales.good_id) FROM sales WHERE good_id = (SELECT id FROM goods WHERE goods.name = 'Ножницы')) AND
--    (SELECT sales.create_date FROM sales WHERE good_id = (SELECT id FROM goods WHERE goods.name = 'Нашивка детская')) =
--    (SELECT sales.create_date FROM sales WHERE good_id = (SELECT id FROM goods WHERE goods.name = 'Ножницы'))
END;
/

