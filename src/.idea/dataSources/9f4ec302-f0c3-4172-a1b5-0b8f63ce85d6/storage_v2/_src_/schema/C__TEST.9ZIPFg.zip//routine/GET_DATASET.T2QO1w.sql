create PROCEDURE get_dataset (date_begin IN date, date_end IN date, good IN NUMBER)
IS
    date1 date;
    date2 date;
    count1 number;
    count2 number;
    cnt INT;

    CURSOR cur IS SELECT * FROM dataset;
BEGIN 
    OPEN cur;
    SELECT COUNT(dataset.date_) INTO cnt FROM dataset;
    IF cnt <= 2
    THEN
      RETURN;
    END IF;
    FETCH cur INTO date1, count1;

    WHILE cnt > 2
    LOOP
        FETCH cur INTO date2, count2;
        count1 := (count1 + count2)/2;
        DELETE FROM dataset WHERE dataset.date_ = date2;
        cnt := cnt - 1;
    END LOOP;
    CLOSE cur;
    UPDATE dataset
    SET dataset.count_req = count1 WHERE dataset.date_ = date1;
END;
/

