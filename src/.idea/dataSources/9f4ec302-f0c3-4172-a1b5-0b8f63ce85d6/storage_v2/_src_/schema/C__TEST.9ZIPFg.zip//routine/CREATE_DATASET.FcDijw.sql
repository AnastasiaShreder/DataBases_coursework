create PROCEDURE create_dataset(date_begin IN date, date_end IN date, good IN NUMBER)
IS
BEGIN
    DELETE FROM dataset;
    INSERT INTO dataset(date_, count_req)
        SELECT sales.create_date as date_, COUNT(goods.id) as count_req FROM sales JOIN goods ON sales.good_id = goods.id 
        WHERE goods.id = good AND sales.create_date BETWEEN date_begin AND date_end 
        GROUP BY sales.create_date, sales.good_id 
        ORDER BY sales.create_date;
END;
/

