create view GOODS_WAREHOUSE1 as
SELECT goods.id, goods.name, warehouse1.good_count FROM warehouse1
INNER JOIN goods ON warehouse1.good_id = goods.id WHERE warehouse1.good_count < 10
/

