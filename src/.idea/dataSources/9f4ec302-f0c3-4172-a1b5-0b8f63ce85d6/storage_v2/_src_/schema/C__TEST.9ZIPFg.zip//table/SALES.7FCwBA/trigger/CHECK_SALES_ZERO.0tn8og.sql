create trigger CHECK_SALES_ZERO
    before insert or update
    on SALES
    for each row
BEGIN
    IF (:NEW.good_count < 1)
    THEN 
        RAISE_APPLICATION_ERROR(-20001,  'В заявке должен быть хотя бы один товар');
    END IF;
END;
/

