create trigger CHECK_SALES_COUNT
    before insert or update
    on SALES
    for each row
DECLARE 
    count1 INT;
    count2 INT;
BEGIN
    SELECT (warehouse1.good_count + warehouse2.good_count) INTO count1
    FROM warehouse1, warehouse2
    WHERE warehouse1.good_id = :NEW.good_id 
    AND warehouse2.good_id = :NEW.good_id;

    IF (:NEW.good_count > count1)
    THEN
        RAISE_APPLICATION_ERROR(-20001,  'Недостаточно товаров на обоих складах');
    END IF;
END;
/

