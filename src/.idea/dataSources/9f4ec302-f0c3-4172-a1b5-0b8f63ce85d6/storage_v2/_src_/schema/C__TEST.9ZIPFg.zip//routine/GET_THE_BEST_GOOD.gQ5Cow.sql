create PROCEDURE get_the_best_good(date_1 IN date, date_2 IN date, id_good OUT NUMBER)
IS
BEGIN
    SELECT goods.id INTO id_good FROM goods 
    INNER JOIN sales ON sales.good_id = goods.id
    WHERE sales.create_date BETWEEN date_1 AND date_2
    GROUP BY goods.id, goods.name
    ORDER BY COUNT(sales.good_id) DESC 
    FETCH FIRST 1 ROWS ONLY;
END;
/

